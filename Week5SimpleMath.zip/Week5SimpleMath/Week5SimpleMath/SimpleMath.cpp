#include <iostream>
#include "SimpleMath.h"

using namespace std;

void SimpleMath::print()
{
	// output sub total
	cout << "\nSub Total: $" << subTotal << endl;
	// output sales tax
	cout << "Sales Tax: $" << salesTax << endl;
	// output total
	cout << "Total: $" << (subTotal + salesTax) << endl;
}

void SimpleMath::setSalesTax(double p[], int c[], int n)
{
	//cout << "Price: " << p[n] << " Category: " << c[n];
	// capture salesTax based on category
	switch (c[n]) {

	case 1:

		salesTax += p[n] * 0.06;

	case 2:

		salesTax += p[n] * 0.07;

	case 3:

		salesTax += p[n] * 0.03;

	case 4:

		salesTax += p[n] * 0.06;

	case 5:

		salesTax += p[n] * 0.03;

	case 6:

		salesTax += p[n] * 0.10;

	}
}

void SimpleMath::setSubTotal(double p[], int n) 
{
	//cout << "Subtotal currently: " << subTotal;
	// add to subtotal
	subTotal += p[n];	
}