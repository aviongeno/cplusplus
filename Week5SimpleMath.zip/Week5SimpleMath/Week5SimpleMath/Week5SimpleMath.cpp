#include<iostream>
#include "SimpleMath.h"

using namespace std;

int main() {
	// set object
	SimpleMath sM;
	// define category
	int category[100];
	// define price, sales tax, sub totals
	double price[100], sales_tax = 0, sub_total = 0;
	// define increment variable
	int n = 0;
	// loop unless broken
	while (1) {
		// menu
		cout << "\n\nCategory 1 - Clothing" << endl;

		cout << "Category 2 - Beauty Products" << endl;

		cout << "Category 3 - Grocery" << endl;

		cout << "Category 4 - Gardening" << endl;

		cout << "Category 5 - School supplies" << endl;

		cout << "Category 6 - Tobacco products" << endl;

		cout << "Choose category(1-6, -1 to exit): ";
		// capture value
		cin >> category[n];
		// escape loop
		if (category[n] == -1)

			break;
		// enter price
		cout << "Enter price of product: ";
		// capture price
		cin >> price[n];
		// capture sales tax
		sM.setSalesTax(price,category,n);
		// add to subtotal
		sM.setSubTotal(price, n);
		// increment array
		n++;

	}
	// print totals
	sM.print();
	// exit
	return 0;

}

