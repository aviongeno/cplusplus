#pragma once


class SimpleMath
{
public:

	void print();

	void setSalesTax(double p[],int c[], int n);

	void setSubTotal(double p[],int n);

private:
	double salesTax = 0, subTotal = 0;

};